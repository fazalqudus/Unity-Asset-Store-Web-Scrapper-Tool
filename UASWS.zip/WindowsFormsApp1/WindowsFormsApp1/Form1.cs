﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.IO;
using System.Collections.Generic;
using System.Xml;
using HtmlAgilityPack;
using System.Diagnostics;
using System.Text.RegularExpressions;
using System.Xml;
using System.Threading;




namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public LinkedList<string> listOfErrors = new LinkedList<string>();
        public string startTime = DateTime.Now.ToString("yyyy-MM-dd h:mm:ss tt");
        public string finishTime = "";

        public LinkedList<asset> Assets = new LinkedList<asset>();
        public class userReview
        {
            public string review;
            public string user;
            public string date;
            public string rating;
            public string rateToAsset;
            public string usefull;
            public string notUserfull;
            public string replyFromPublisher;
           // public string dateOfReplyFromPublisher;
            public string title;
            public string onUnityVersion = "";

            public string getInString()
            {
                string output = "";
                output = "Reviwer:" + user + ", Date:" + date + ", On Unity version:" + onUnityVersion + ", Review title:" + title + ", Rating:" + rating + ", Review:" + review + ", Number of users who agree with this review:" + usefull + ", Number of users who don't agree with this review:" + notUserfull + ", Reply from the publisher:" + replyFromPublisher;

                return output;
            }
            public string getInXML()
            {
                string output = "";
                output = "<Reviwer>" + user + "</Reviwer><date>" + date + "</date><onUnityVersion>" + onUnityVersion + "</onUnityVersion><title>" + title + "</title><rating>" + rating + "</rating><review>" + review + "</review><usefull>" + usefull + "</usefull><notUsefull>" + notUserfull + "</notUsefull><replyFromPublisher>" + replyFromPublisher + "</replyFromPublisher>";
                return output;
            }
            // we can also get all reviews from the same user but in the data proccessing ap.
        }
        
        public class asset {
            // url, title, sub-category, description, original price, final price, file size, number of files, Supported Unity versions, number of user reviews, rating, number of users voted for the rating, number of releases, first published date, last published date,author,tags 
            public string url;
            public string title;
            public string imgLink;
            public string subCategory;
            public string description;
            public string originalPrice;
            public string finalPrice;
            public string fileSize;
            public string numberOfFiles;
            public string supportedUnityVersions;
            public string supportedUnityVersionsNumeric;
            public string rating;
            public string numberOfVotes; // cofidence in the rating
            public string numberReviews;
            public int numberOfReleases;
            public string firstReleaseDate;
            public string lastReleaseDate;
            // we should also calculate the average time between releases but in the data proccessing ap.
            public string publisher;
            public string allReleases;
            public string tags;
            public int CountStringOccurrences(string text, string pattern)
            {
                // Loop through all instances of the string 'text'.
                int count = 0;
                int i = 0;
                while ((i = text.IndexOf(pattern, i)) != -1)
                {
                    i += pattern.Length;
                    count++;
                }
                return count;
            }

            public string getReviewsInXML()
            {
                string output = "<Reviews>";
                foreach (userReview u in userReviewsList)
                {
                    output = output + "<Review>" + u.getInXML() + "</Review>";
                }
                return output+ "</Reviews>";
            }
            public string getReviewsInString()
            {
                string output = "";
                
                foreach (userReview u in userReviewsList)
                {
                    output = output + "<Review>"+u.getInString()+ "</Review>";
                    
                }
                return output;
            }
            public LinkedList<userReview> userReviewsList = new LinkedList<userReview>();
            public String stripNonValidXMLCharacters(string textIn)
            {
                StringBuilder textOut = new StringBuilder(); // Used to hold the output.
                char current; // Used to reference the current character.


                if (textIn == null || textIn == string.Empty) return string.Empty; // vacancy test.
                for (int i = 0; i < textIn.Length; i++)
                {
                    current = textIn[i];


                    if ((current == 0x9 || current == 0xA || current == 0xD) ||
                        ((current >= 0x20) && (current <= 0xD7FF)) ||
                        ((current >= 0xE000) && (current <= 0xFFFD)) ||
                        ((current >= 0x10000) && (current <= 0x10FFFF)))
                    {
                        textOut.Append(current);
                    }
                }
                string to= textOut.ToString();
                to = Regex.Replace(to, @"\s+", " ");
                to = to.Replace("<br>", "");
                to = to.Replace("<","");
                to = to.Replace(">", "");
                to = to.Replace("&nbsp", "");
                to = to.Replace("&gt", "");
                



                return to;
            }
            public string returnXMLRow() {
                return "<asset>" + "<URL>" + url + "</URL>" + "<title>" + stripNonValidXMLCharacters(title) + "</title>" +"<imageLink>"+imgLink+ "</imageLink>"
                    + "<subCategory>" + subCategory + "</subCategory>" + "<description>" + stripNonValidXMLCharacters(description) + "</description>" 
                    + "<originalPrice>" + originalPrice + "</originalPrice>" + "<finalPrice>" + finalPrice + "</finalPrice>" 
                    +"<rating>"+rating+"</rating>"+"<numberOfVoters>"+numberOfVotes+"</numberOfVoters>"
                    +"<publisher>"+ stripNonValidXMLCharacters(publisher) + "</publisher>"+"<size>"+fileSize+"</size>"
                    + "<numberOfFiles>" +numberOfFiles+ "</numberOfFiles>" +"<unityVersion>"+supportedUnityVersions+"</unityVersion>" + "<unityVersionNumeric>" + supportedUnityVersionsNumeric + "</unityVersionNumeric>"
                    + "<firstReleaseDate>"+firstReleaseDate+ "</firstReleaseDate>" + "<lastReleaseDate>" + lastReleaseDate + "</lastReleaseDate>"
                    + "<numberOfReleases>" +numberOfReleases.ToString()+ "</numberOfReleases>" + "<allReleaseDates>" + allReleases + "</allReleaseDates>"
                    + "<numberOfReviews>"+numberReviews+ "</numberOfReviews>" +tags+"</asset>" ;  }
            public string returnXMLRowLite()
            {
                return "<asset>" + "<URL>" + url + "</URL>" + "<title>" + stripNonValidXMLCharacters(title) + "</title>" 
                    + "<subCategory>" + subCategory + "</subCategory>" 
                    + "<originalPrice>" + originalPrice + "</originalPrice>" + "<finalPrice>" + finalPrice + "</finalPrice>"
                    + "<rating>" + rating + "</rating>" + "<numberOfVoters>" + numberOfVotes + "</numberOfVoters>"
                    + "<publisher>" + stripNonValidXMLCharacters(publisher) + "</publisher>" + "<size>" + fileSize + "</size>"
                    + "<numberOfFiles>" + numberOfFiles + "</numberOfFiles>" + "<unityVersion>" + supportedUnityVersions + "</unityVersion>" + "<unityVersionNumeric>" + supportedUnityVersionsNumeric + "</unityVersionNumeric>"
                    + "<firstReleaseDate>" + firstReleaseDate + "</firstReleaseDate>" + "<lastReleaseDate>" + lastReleaseDate + "</lastReleaseDate>"
                    + "<numberOfReleases>" + numberOfReleases.ToString() + "</numberOfReleases>" 
                    + "<numberOfReviews>" + numberReviews + "</numberOfReviews>" + "</asset>";
            }
            public string returnXMLRowForFSE()
            {
                return "<Feature><name>"+ stripNonValidXMLCharacters(title)+"</name>"+"<category>" + subCategory + "</category>"+ "<properties>"
                   
                    + "<property><name>URL</name><value>" + url + "</value></property>"
                    + "<property><name>imageLink</name><value>" + imgLink + "</value></property>"
                    + "<property><name>description</name><value>" + stripNonValidXMLCharacters(description) + "</value></property>"
                    + "<property><name>originalPrice</name><value>" + originalPrice + "</value></property>"
                    + "<property><name>finalPrice</name><value>" + finalPrice + "</value></property>"
                    + "<property><name>rating</name><value>" + rating + "</value></property>"
                    + "<property><name>numberOfVotes</name><value>" + numberOfVotes+ "</value></property>"
                    + "<property><name>publisher</name><value>" + stripNonValidXMLCharacters(publisher) + "</value></property>"
                    + "<property><name>size</name><value>" + fileSize + "</value></property>"
                    + "<property><name>numberOfFiles</name><value>" + numberOfFiles + "</value></property>"
                    + "<property><name>supportedUnityVersion</name><value>" + supportedUnityVersions + "</value></property>"
                    + "<property><name>supportedUnityVersionNumeric</name><value>" + supportedUnityVersionsNumeric + "</value></property>"
                    + "<property><name>firstReleaseDate</name><value>" + firstReleaseDate + "</value></property>"
                    + "<property><name>lastReleaseDate</name><value>" + lastReleaseDate + "</value></property>"
                    + "<property><name>numberOfReleases</name><value>" + numberOfReleases.ToString() + "</value></property>"
                    + "<property><name>allReleaseDates</name><value>" + allReleases + "</value></property>"
                    + "<property><name>numberOfReviews</name><value>" + numberReviews + "</value></property>"
                    + "<property><name>tags</name><value>" + tags + "</value></property>"
                    
                    + "</properties></Feature>";
            }
            public string returnXMLRowForFSE_LITE()
            {
                return "<Feature><name>" + stripNonValidXMLCharacters(title) + "</name>" + "<category>" + subCategory + "</category>" + "<properties>"

                    + "<property><name>URL</name><value>" + url + "</value></property>"
                    + "<property><name>imageLink</name><value>" + imgLink + "</value></property>"
                    //+ "<property><name>description</name><value>" + stripNonValidXMLCharacters(description) + "</value></property>"
                    + "<property><name>originalPrice</name><value>" + originalPrice + "</value></property>"
                    + "<property><name>finalPrice</name><value>" + finalPrice + "</value></property>"
                    + "<property><name>rating</name><value>" + rating + "</value></property>"
                    + "<property><name>numberOfVotes</name><value>" + numberOfVotes + "</value></property>"
                    + "<property><name>publisher</name><value>" + stripNonValidXMLCharacters(publisher) + "</value></property>"
                    + "<property><name>size</name><value>" + fileSize + "</value></property>"
                    + "<property><name>numberOfFiles</name><value>" + numberOfFiles + "</value></property>"
                    + "<property><name>supportedUnityVersion</name><value>" + supportedUnityVersions + "</value></property>"
                    + "<property><name>supportedUnityVersionNumeric</name><value>" + supportedUnityVersionsNumeric + "</value></property>"
                    + "<property><name>firstReleaseDate</name><value>" + firstReleaseDate + "</value></property>"
                    + "<property><name>lastReleaseDate</name><value>" + lastReleaseDate + "</value></property>"
                    + "<property><name>numberOfReleases</name><value>" + numberOfReleases.ToString() + "</value></property>"
                    //+ "<property><name>allReleaseDates</name><value>" + allReleases + "</value></property>"
                    + "<property><name>numberOfReviews</name><value>" + numberReviews + "</value></property>"
                   // + "<property><name>tags</name><value>" + tags + "</value></property>"

                    + "</properties></Feature>";
            }
            public string returnXMLRowWithReviews()
            {
                return "<asset>" + "<URL>" + url + "</URL>" + "<title>" + stripNonValidXMLCharacters(title) + "</title>" + "<imageLink>" + imgLink + "</imageLink>"
                    + "<subCategory>" + subCategory + "</subCategory>" + "<description>" + stripNonValidXMLCharacters(description) + "</description>"
                    + "<originalPrice>" + originalPrice + "</originalPrice>" + "<finalPrice>" + finalPrice + "</finalPrice>"
                    + "<rating>" + rating + "</rating>" + "<numberOfVoters>" + numberOfVotes + "</numberOfVoters>"
                    + "<publisher>" + stripNonValidXMLCharacters(publisher) + "</publisher>" + "<size>" + fileSize + "</size>"
                    + "<numberOfFiles>" + numberOfFiles + "</numberOfFiles>" + "<unityVersion>" + supportedUnityVersions + "</unityVersion>" + "<unityVersionNumeric>" + supportedUnityVersionsNumeric + "</unityVersionNumeric>"
                    + "<firstReleaseDate>" + firstReleaseDate + "</firstReleaseDate>" + "<lastReleaseDate>" + lastReleaseDate + "</lastReleaseDate>"
                    + "<numberOfReleases>" + numberOfReleases.ToString() + "</numberOfReleases>" + "<allReleaseDates>" + allReleases + "</allReleaseDates>"
                    + "<numberOfReviews>" + numberReviews + "</numberOfReviews>" +getReviewsInXML() + tags + "</asset>";
            }
            public string returnXMLRowForFSEwithReviews()
            {
                return "<Feature><name>" + stripNonValidXMLCharacters(title) + "</name>" + "<category>" + subCategory + "</category>" + "<properties>"

                    + "<property><name>URL</name><value>" + url + "</value></property>"
                    + "<property><name>imageLink</name><value>" + imgLink + "</value></property>"
                    + "<property><name>description</name><value>" + stripNonValidXMLCharacters(description) + "</value></property>"
                    + "<property><name>originalPrice</name><value>" + originalPrice + "</value></property>"
                    + "<property><name>finalPrice</name><value>" + finalPrice + "</value></property>"
                    + "<property><name>rating</name><value>" + rating + "</value></property>"
                    + "<property><name>numberOfVotes</name><value>" + numberOfVotes + "</value></property>"
                    + "<property><name>publisher</name><value>" + stripNonValidXMLCharacters(publisher) + "</value></property>"
                    + "<property><name>size</name><value>" + fileSize + "</value></property>"
                    + "<property><name>numberOfFiles</name><value>" + numberOfFiles + "</value></property>"
                    + "<property><name>supportedUnityVersion</name><value>" + supportedUnityVersions + "</value></property>"
                    + "<property><name>supportedUnityVersionNumeric</name><value>" + supportedUnityVersionsNumeric + "</value></property>"
                    + "<property><name>firstReleaseDate</name><value>" + firstReleaseDate + "</value></property>"
                    + "<property><name>lastReleaseDate</name><value>" + lastReleaseDate + "</value></property>"
                    + "<property><name>numberOfReleases</name><value>" + numberOfReleases.ToString() + "</value></property>"
                    + "<property><name>allReleaseDates</name><value>" + allReleases + "</value></property>"
                    + "<property><name>numberOfReviews</name><value>" + numberReviews + "</value></property>"
                    + "<property><name>Reviews</name><value>" + getReviewsInString() + "</value></property>"
                    + "<property><name>tags</name><value>" + tags + "</value></property>"

                    + "</properties></Feature>";
            }


        }

        public Form1()
        {
            InitializeComponent();
            comboBox1.SelectedIndex = 0;
        textBox1.Text = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            

        }
        public bool IsCharDigit(char c)
        {
            return ((c >= '0') && (c <= '9'));
        }
        
        public static string TakeScreenshot(string u,string chromePath)
        {
            var pathToBrowser = @chromePath;
            var arguments = $@" --headless --disable-gpu --enable-logging --hide-scrollbars --delay=500  --dump-dom "+u;
            var psi = new ProcessStartInfo(pathToBrowser, arguments) { UseShellExecute = false, Verb = "runas", RedirectStandardOutput = true };
            Process process = new Process();
            process.StartInfo = psi;

            process.Start();
            var output = process.StandardOutput.ReadToEnd();
            process.Close();

            return output;


        }

        private bool assetAlreadyLoaded(string url, bool update) {

            if (update) //if update is false then no need to check as it does not exist
            {
                foreach (asset a in Assets) 
                {
                    if (a.url.Equals(url))
                    {
                     //   MessageBox.Show("asset found");
                        return true;
                    }

                }


            }
            return false;

        }
        private string removeUnwantedChar(string input)
        {
            string correctString = "";

            for (int i = 0; i < input.Length; i++)
            {
                if (char.IsDigit(input[i]) || input[i] == '.' || input[i] == '-' || char.IsLetter(input[i])
                       || input[i] == '%' || input[i] == '+' || input[i] == '*' || input[i] == '/' || input[i] == '_' || input[i] == '('
                       || input[i] == ')' || input[i] == '[' || input[i] == ']' || input[i] == '^' || input[i] == '#' || input[i] == '@'
                       || input[i] == '$' || input[i] == '!' || input[i] == '`' || input[i] == '{' || input[i] == '}' || input[i] == '='
                       || input[i] == '~' || input[i] == ';' || input[i] == '?' || input[i] == '/' || input[i] == '>' || input[i] == '<' || input[i] == ' ')
                    correctString += input[i];
            }
            return correctString;
        }
        private void getData(bool update)
        {
            button1.Enabled = false;
            button4.Enabled = false;

            if (update) // if update existing file, then first load all data from the file to assets. 
            {
                string line="";
                OpenFileDialog openFileDialog1 = new OpenFileDialog();
                openFileDialog1.Filter = "XML Files|*.xml";
                openFileDialog1.Title = "Select the xml file to be updated";
                if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    XmlDataDocument xmldoc = new XmlDataDocument();
                    XmlNodeList xmlnode;
                    System.IO.StreamReader file = new System.IO.StreamReader(openFileDialog1.FileName);
                    xmldoc.Load(file);
                    file.Close();

                    xmlnode = xmldoc.GetElementsByTagName("asset");
                  //  MessageBox.Show((xmlnode[0].ChildNodes.Item(16).ChildNodes.Count).ToString());
                        //Item(0).InnerText.Trim());

                    for (int i = 0; i <= xmlnode.Count - 1; i++)
                    {
                        asset tempA = new asset();
                        tempA.url = xmlnode[i].ChildNodes.Item(0).InnerText.Trim();
                        tempA.title = xmlnode[i].ChildNodes.Item(1).InnerText.Trim();
                        tempA.imgLink = xmlnode[i].ChildNodes.Item(2).InnerText.Trim();
                        tempA.subCategory = xmlnode[i].ChildNodes.Item(3).InnerText.Trim();
                        tempA.description = xmlnode[i].ChildNodes.Item(4).InnerText.Trim();
                        tempA.originalPrice = xmlnode[i].ChildNodes.Item(5).InnerText.Trim();
                        tempA.finalPrice = xmlnode[i].ChildNodes.Item(6).InnerText.Trim();
                        tempA.rating = xmlnode[i].ChildNodes.Item(7).InnerText.Trim();
                        tempA.numberOfVotes = xmlnode[i].ChildNodes.Item(8).InnerText.Trim();
                        tempA.publisher = xmlnode[i].ChildNodes.Item(9).InnerText.Trim();
                        tempA.fileSize = xmlnode[i].ChildNodes.Item(10).InnerText.Trim();
                        tempA.numberOfFiles = xmlnode[i].ChildNodes.Item(11).InnerText.Trim();
                        tempA.supportedUnityVersions = xmlnode[i].ChildNodes.Item(12).InnerText.Trim();
                        tempA.firstReleaseDate = xmlnode[i].ChildNodes.Item(13).InnerText.Trim();
                        tempA.lastReleaseDate = xmlnode[i].ChildNodes.Item(14).InnerText.Trim();
                        tempA.numberOfReleases = Int32.Parse(xmlnode[i].ChildNodes.Item(15).InnerText.Trim());
                        line = "";
                        for (int ii = 0; ii <= xmlnode[i].ChildNodes.Item(16).ChildNodes.Count - 1; ii++)
                       {
                            if (line.Length>0) { line = line + ","; }
                            line = line + xmlnode[i].ChildNodes.Item(16).ChildNodes.Item(ii).InnerText.Trim() ;
                            tempA.allReleases = line;
                        }
                        
                        tempA.numberReviews = xmlnode[i].ChildNodes.Item(17).InnerText.Trim();

                        line = "";
                        for (int ii = 0; ii <= xmlnode[i].ChildNodes.Item(18).ChildNodes.Count - 1; ii++)
                        {
                            if (line.Length > 0) { line = line + ","; }
                            line = line + xmlnode[i].ChildNodes.Item(18).ChildNodes.Item(ii).InnerText.Trim() ;
                            tempA.tags = line;
                        }
                        line = "";

                        Assets.AddLast(tempA);

                    }

                }
                else
                {
                    button4.Enabled = true;
                    button1.Enabled = true;
                    return;
                }

            }
           
            bool userUrl = false;

            bool allAssets = false;
            string tu = "";
            if (comboBox2.SelectedIndex > 0)
            {
                tu = "https://assetstore.unity.com/categories" + comboBox2.Text;
            }
            else if (comboBox2.SelectedIndex == 0) // all assets
            {
                tu = "https://assetstore.unity.com/search?rows=1";
                allAssets = true;
            }
            else
            { // if a user url 
                tu = comboBox2.Text;
                userUrl = true;

                // check if valid url
                if (tu.IndexOf("https://")==-1)
                {
                    MessageBox.Show("No valid URL was supplied");
                    button1.Enabled = true;
                    button4.Enabled = true;
                    return;
                }
               
                
            }
            
            string tempSting = "";
            HtmlWeb web = new HtmlWeb();
            var htmlDoc = web.Load(tu);
            string s = htmlDoc.Text;


            int tempCount = 0;
            HtmlNode node = htmlDoc.DocumentNode.SelectNodes("//div[contains(@class,'_1v5JV')]").First();
            tempSting = node.InnerHtml.ToString();
            // get the number of assets under this search
            string numberOfAssetsFound = "";
            tempSting = tempSting.Replace("Showing", "");
            tempSting = tempSting.Replace("Results", "");
            numberOfAssetsFound = tempSting.Trim();

            // find number of pages, by dividing the total number of assets in this category by the number of items per page
            int numberOfAssetsPerPage = 100; // developer defined variable
                                             // MessageBox.Show(numberOfAssetsFound);
            int numberOfPages = Int32.Parse(numberOfAssetsFound) / numberOfAssetsPerPage;

            LinkedList<asset> tempAssets = new LinkedList<asset>();
            for (int i = 0; i < numberOfPages + 1; i++)
            {
                try
                {
                    int safetyExitCounter = 0;
                    Point0:
                    safetyExitCounter++;
                    try
                    {
                        if (userUrl) { i = numberOfPages + 1; }
                        else if (allAssets)
                        {

                            tu = "https://assetstore.unity.com/search" + "?rows=" + numberOfAssetsPerPage + "&page=" + i.ToString();

                            htmlDoc = web.Load(tu);




                            s = htmlDoc.Text;

                        }
                        else
                        {

                            // create new url
                            tu = "https://assetstore.unity.com/categories" + comboBox2.Text + "?rows=" + numberOfAssetsPerPage + "&page=" + i.ToString();
                            // download url

                            htmlDoc = web.Load(tu);


                            s = htmlDoc.Text;


                        }
                    }
                    catch
                    {
                        if (safetyExitCounter < 3)
                        {
                            listOfErrors.AddLast("Re-try to access URL: "+tu);
                            goto Point0;

                        }
                        else
                        {
                            string output = "An exception has occur while accessing " + tu;
                            //Console.WriteLine(output);
                            listOfErrors.AddLast(output);
                            button3.Visible = true;
                        }
                    }

                    int numberOfItemsInThePage = 0;
                    //      MessageBox.Show(tu);
                    // step 1 create assets in Assets and get the URLs of all assets under this category
                    while (s.IndexOf("_1ClTv") != -1)
                    {


                        s = s.Remove(0, s.IndexOf("_1ClTv") + 14);
                        s.TrimStart();

                        string tempUrl = "https://assetstore.unity.com" + (s.Substring(0, s.IndexOf("\" data-reactid"))).TrimStart();

                        try
                        {
                            // if update check if the asset has already been proccessed. 
                            if (assetAlreadyLoaded(tempUrl, update) == false)
                            {
                                asset tempAsset = new asset();


                                tempAsset.url = tempAsset.stripNonValidXMLCharacters(tempUrl);



                                // get original price


                                if (IsCharDigit(s[s.IndexOf("finalPrice") - 10]))
                                {
                                    tempSting = s.Substring(s.IndexOf("finalPrice") - 10, 7);
                                }
                                else if (IsCharDigit(s[s.IndexOf("finalPrice") - 9]))
                                {
                                    tempSting = s.Substring(s.IndexOf("finalPrice") - 9, 6);
                                }
                                else if (IsCharDigit(s[s.IndexOf("finalPrice") - 8]))
                                {
                                    tempSting = s.Substring(s.IndexOf("finalPrice") - 8, 5);
                                }
                                else
                                {
                                    tempSting = s.Substring(s.IndexOf("finalPrice") - 7, 4);
                                }
                                // the above checks if the price is over 99 usd so 5 digits or 4 digits
                                tempAsset.originalPrice = tempAsset.stripNonValidXMLCharacters(tempSting);

                                // get finalPrice
                                if (IsCharDigit(s[s.IndexOf("finalPrice") + 19]))
                                {
                                    tempSting = s.Substring(s.IndexOf("finalPrice") + 13, 7);
                                }
                                else if (IsCharDigit(s[s.IndexOf("finalPrice") + 18]))
                                {
                                    tempSting = s.Substring(s.IndexOf("finalPrice") + 13, 6);
                                }
                                else if (IsCharDigit(s[s.IndexOf("finalPrice") + 17]))
                                {
                                    tempSting = s.Substring(s.IndexOf("finalPrice") + 13, 5);
                                }
                                else
                                {
                                    tempSting = s.Substring(s.IndexOf("finalPrice") + 13, 4);

                                }
                                tempAsset.finalPrice = tempAsset.stripNonValidXMLCharacters(tempSting);
                                s = s.Remove(s.IndexOf("finalPrice"), 10);






                                tempAssets.AddLast(tempAsset);
                                numberOfItemsInThePage++;
                                label1.Text = (tempAssets.Count()).ToString() + " / " + numberOfAssetsFound + " temporal assets added ";
                                //Console.WriteLine((tempAssets.Count()).ToString() + " / " + numberOfAssetsFound + " temporal assets added " + " Date/Time:" + DateTime.Now.ToString("yyyy-MM-dd h:mm:ss tt"));
                                Application.DoEvents();




                            }
                        }
                        catch
                        {
                            string output = "An exception has occur while proccesing " + tempUrl;
                            //Console.WriteLine(output);
                            listOfErrors.AddLast(output);
                            button3.Visible = true;


                            tempCount++;
                        }

                    }
                    // self test
                    // if entries not match the expected number then report it as an error in this page and not the last page
                    if ((numberOfItemsInThePage != numberOfAssetsPerPage) && (i < numberOfPages))
                    {
                        string output = " items were not added from page " + tu;
                        listOfErrors.AddLast(output);
                        button3.Visible = true;


                    }
                }
                catch
                {
                    string output = "An exception has occur while accessing " + tu;
                    //Console.WriteLine(output);
                    listOfErrors.AddLast(output);
                    button3.Visible = true;
                }
            }
            // end of step 1 
            // step 2: Vist each URL and extract the info
            tempCount = 0;
            int backupCount = 0;
            
            string chromePath = textBox3.Text.Trim();
            foreach (asset aa in tempAssets)
            {
                int secCounter = 0;
                string LastError = "";
            if (listOfErrors.Count>0)
                {
                    LastError = listOfErrors.Last();
                }
            Processing:
                secCounter++;
                string label1Output = "Started: " + startTime + " Assets processed: " + tempCount.ToString() + " Assets remaining: " + (tempAssets.Count() - tempCount).ToString()+"  "+ LastError;
                label1.Text = label1Output;
                Application.DoEvents();
            //  Label1Updater(label1Output);
            

                string tmpU = aa.url;
                try
                {
                    string webSiteCode = "";
                    var task = Task.Run(() => removeUnwantedChar(TakeScreenshot(tmpU, chromePath)));
                    if (task.Wait(TimeSpan.FromSeconds(60)))
                    {
                        webSiteCode = task.Result;

                    }
                    else
                    {
                        listOfErrors.AddLast("Timed out while accessing: "+tmpU);
                        throw new Exception("Timed out");
                    }
                    


                    htmlDoc.LoadHtml(webSiteCode);

                }
                catch
                {
                    if (secCounter < 3) { listOfErrors.AddLast("re-try to access " + aa.url); goto Processing; }
                    else
                    {

                        string output = "An exception has occur while accessing " + aa.url;
                        //Console.WriteLine(output);
                        listOfErrors.AddLast(output);
                        button3.Visible = true;
                    }
                }
                //testing

                // node = htmlDoc.DocumentNode.SelectNodes("//div[contains(@class,'_3S5OX')]").First();
                // tempSting = node.InnerHtml.ToString();
                //MessageBox.Show(tempSting);

                // end of testing area

                try
                {
                 

                    string s1 = htmlDoc.Text;

                    

                    //Console.WriteLine(tmpU);
                    //Console.WriteLine("Assets added:" + tempCount.ToString() + " Assets in the category:" + numberOfAssetsFound + " Date/Time:" + DateTime.Now.ToString("yyyy-MM-dd h:mm:ss tt"));
                    //label1.Text = "Assets added:" + tempCount.ToString() + " Assets in the category:" + numberOfAssetsFound;
                    // url, title, sub-category, description, original price, final price, file size, number of files, Supported Unity versions, number of user reviews, rating, number of users voted for the rating, number of releases, first published date, last published date,author,tags 

                    // get title
                    s1 = s1.Remove(0, s1.IndexOf("<title>") + 7);
                        s1.TrimStart();
                        tempSting = (s1.Substring(0, s1.IndexOf("- Asset Store")).Trim());
                        aa.title = aa.stripNonValidXMLCharacters(removeUnwantedChar(tempSting));
                        // get sub-category
                        tempSting = tmpU;
                        tempSting = tempSting.Remove(tempSting.LastIndexOf("/") );
                        tempSting = tempSting.Substring(38);

                        aa.subCategory = aa.stripNonValidXMLCharacters(tempSting);
                        // get image
                        tempSting = s1;
                        tempSting = tempSting.Substring(tempSting.IndexOf("_6EfUH"));
                        tempSting = tempSting.Substring(tempSting.IndexOf("src=") + 5);
                        aa.imgLink = "https:" + tempSting.Substring(0, tempSting.IndexOf(".jpg") + 4);

                    // get description
                    

                    node = htmlDoc.DocumentNode.SelectNodes("//div[contains(@class,'FthBO')]").First();
                        tempSting = node.InnerHtml.ToString();

                        //  s1 = s1.Substring(s1.IndexOf("description") + 22);
                        //  tempSting = s1.Substring(0, s1.IndexOf(">") - 2);
                        tempSting.Trim();
                        aa.description = aa.stripNonValidXMLCharacters(removeUnwantedChar(tempSting));
                        // get rating and numberOfVoters

                        if (s1.IndexOf("Rated 5 stars out of 5 stars") > -1)
                        {
                            aa.rating = "5";
                            tempSting = (s1.Substring(s1.IndexOf("Rated 5 stars out of 5 stars") + 30).TrimStart());
                            aa.numberOfVotes = tempSting.Substring(0, tempSting.IndexOf("user") - 1);

                        }
                        else if (s1.IndexOf("Rated 4 stars out of 5 stars") > -1)
                        {
                            aa.rating = "4";
                            tempSting = (s1.Substring(s1.IndexOf("Rated 4 stars out of 5 stars") + 30).TrimStart());
                            aa.numberOfVotes = tempSting.Substring(0, tempSting.IndexOf("user") - 1);

                        }
                        else if (s1.IndexOf("Rated 3 stars out of 5 stars") > -1)
                        {
                            aa.rating = "3";
                            tempSting = (s1.Substring(s1.IndexOf("Rated 3 stars out of 5 stars") + 30).TrimStart());
                            aa.numberOfVotes = tempSting.Substring(0, tempSting.IndexOf("user") - 1);

                        }
                        else if (s1.IndexOf("Rated 2 stars out of 5 stars") > -1)
                        {
                            aa.rating = "2";
                            tempSting = (s1.Substring(s1.IndexOf("Rated 2 stars out of 5 stars") + 30).TrimStart());
                            aa.numberOfVotes = tempSting.Substring(0, tempSting.IndexOf("user") - 1);

                        }
                        else if (s1.IndexOf("Rated 1 stars out of 5 stars") > -1)
                        {
                            aa.rating = "1";
                            tempSting = (s1.Substring(s1.IndexOf("Rated 1 stars out of 5 stars") + 30).TrimStart());
                            aa.numberOfVotes = tempSting.Substring(0, tempSting.IndexOf("user") - 1);

                        }
                        else
                        {
                            aa.rating = "0";
                            aa.numberOfVotes = "0";
                        }
                // get publisher  _3S5OX
        //        node = htmlDoc.DocumentNode.SelectNodes("//div[contains(@class,'_3S5OX')]").First();
          //       MessageBox.Show(node.InnerHtml.ToString());

                tempSting = s1.Substring(s1.IndexOf("_3S5OX"));
                        tempSting = (tempSting.Substring(tempSting.IndexOf(">") + 1)).TrimStart(); ;

                        aa.publisher = aa.stripNonValidXMLCharacters(removeUnwantedChar(tempSting.Substring(0, tempSting.IndexOf("</a>"))));
                // get Total file size
                node = htmlDoc.DocumentNode.SelectNodes("//div[contains(@class,'_2EQ7S')]").First();
                tempSting = node.InnerHtml.ToString();
                    int sizeIn = -1;
                    if (tempSting.IndexOf("MB<!") != -1)
                    {
                        tempSting = tempSting.Substring(0, tempSting.IndexOf("MB<!") + 2);
                        sizeIn = 1;
                    }
                    else if (tempSting.IndexOf("KB<!") != -1)
                    {
                        tempSting = tempSting.Substring(0, tempSting.IndexOf("KB<!") + 2);
                        sizeIn = 0;
                    }
                    else if (tempSting.IndexOf("GB<!") != -1)
                    {
                        tempSting = tempSting.Substring(0, tempSting.IndexOf("GB<!") + 2);
                        sizeIn = 2;
                    }
                    tempSting = aa.stripNonValidXMLCharacters((tempSting.Substring(tempSting.LastIndexOf("-->") + 3)).Trim());
                    aa.fileSize = tempSting.Trim();

                    try
                    {
                        if (sizeIn>-1) {
                            
                            decimal sizeVal = Decimal.Parse(tempSting.Substring(0, tempSting.Length - 2).Trim());
                            if (sizeIn==1)
                            {
                                sizeVal= sizeVal * 1024;
                            }else if (sizeIn==2)
                            {
                                sizeVal = sizeVal * 1024*1024;
                            }
                            aa.fileSize = sizeVal.ToString();
                        }
                    }
                    catch
                    {
                        string output = "An exception while converting the file size of " + aa.url;
                        //Console.WriteLine(output);
                        listOfErrors.AddLast(output);
                        button3.Visible = true;
                    }


                // get number of files
                        tempSting = s1.Substring(s1.IndexOf("Number of files"));
                        tempSting = tempSting.Substring(0, tempSting.IndexOf("_2W3i5"));
                        tempSting = tempSting.Substring(0, tempSting.LastIndexOf("<!--"));
                        aa.numberOfFiles = aa.stripNonValidXMLCharacters(tempSting.Substring(tempSting.LastIndexOf("-->") + 3));
                // get supported unity versions
                node = htmlDoc.DocumentNode.SelectNodes("//div[contains(@class,'_21cZE')]").First();
                tempSting = aa.stripNonValidXMLCharacters(node.InnerText.ToString()).Trim();

                    aa.supportedUnityVersions = tempSting;
                    try
                    {
                        tempSting = tempSting.Substring(tempSting.IndexOf("Unity") + 5).Trim();
                        string tempStringNumeric = "";
                        foreach (char c in tempSting)
                        {
                            if (IsCharDigit(c)||c=='.')
                            {
                                tempStringNumeric = tempStringNumeric + c;
                            }
                            else if (c==' '){ break; }
                        }
                        aa.supportedUnityVersionsNumeric = tempStringNumeric+"0";
                        if (aa.supportedUnityVersionsNumeric[0]=='.') { aa.supportedUnityVersionsNumeric = (aa.supportedUnityVersionsNumeric.Substring(1)).Trim();  }
                    }
                    catch
                    {
                        string output = "An exception while converting the supported unity version to numeric for URL: " + aa.url;
                        //Console.WriteLine(output);
                        listOfErrors.AddLast(output);
                        button3.Visible = true;
                    }

                // get releases and number of releases
                    node = htmlDoc.DocumentNode.SelectNodes("//div[contains(@class,'c9X_z')]").First();
                tempSting = node.InnerHtml.ToString();
                
                //tempSting = s1;
                        string tempString2 = "";
                string tempString3 = "";
                        aa.numberOfReleases = 0;
                    int whileForcedExitCounter = 0;
                    while ((tempSting.IndexOf("-->released") != -1)|| whileForcedExitCounter>500)
                        {
                        whileForcedExitCounter++;
                            tempSting = (tempSting.Substring(tempSting.IndexOf("-->released") + 12)).TrimStart();
                    tempString3 = "";
                            //  System.Windows.Forms.MessageBox.Show(tempSting[5].ToString());
                            // if the released is followed by react-text then is a release date and can be added. 
                    if (IsCharDigit(tempSting[5]))
                            {

                        //aa.allReleases = aa.allReleases + tempSting.Substring(0, 12) + ",";
                        tempString3=  tempSting.Substring(0, 12) ;
                                //     System.Windows.Forms.MessageBox.Show(tempSting.Substring(0, 12));
                                //     System.Windows.Forms.MessageBox.Show(tempString2);


                            }
                            else
                            {
                        //aa.allReleases = aa.allReleases + tempSting.Substring(0, 11) + ",";
                        tempString3=  tempSting.Substring(0, 11) ;
                                //      System.Windows.Forms.MessageBox.Show(tempSting.Substring(0, 11));
                                //     System.Windows.Forms.MessageBox.Show(tempString2);


                            }
                    if (tempString2.Length>0) { tempString2 = tempString2 + "," + tempString3; } else { tempString2 = tempString2 +  tempString3; }
                   
                            // get first release date
                            if (aa.numberOfReleases==0) {
                        aa.firstReleaseDate = aa.stripNonValidXMLCharacters(tempString3).Trim();
                    }
                            // the last date will be the last release date
                    aa.lastReleaseDate = aa.stripNonValidXMLCharacters(tempString3).Trim();

                            aa.numberOfReleases++;
                        }
                    
                    aa.allReleases = aa.stripNonValidXMLCharacters(tempString2).Trim();
                 
                   
               
                        // get number of reviews
                        tempSting = s1; 
                    if (tempSting.IndexOf("_2NJ4r") == -1) { aa.numberReviews = "0"; }
                        else
                        {
                            tempSting = tempSting.Substring(tempSting.IndexOf("_2NJ4r"));
                            tempSting = tempSting.Substring(tempSting.IndexOf(">")+1);
                            aa.numberReviews = aa.stripNonValidXMLCharacters((tempSting.Substring(0, tempSting.IndexOf("user")).Trim()));
                        }
                    // get tags
                    
                    tempSting = s1;
                    tempString2 = "";

                   if (tempSting.IndexOf("Eh1GG _15pcy") != -1)
                    {
                       // MessageBox.Show(htmlDoc.DocumentNode.SelectNodes("//div[contains(@class,'_34rqj')]").First().InnerHtml.ToString());

                        HtmlNode[]nodes = htmlDoc.DocumentNode.SelectNodes("//div[contains(@class,'Eh1GG')]").ToArray();
                        foreach (HtmlNode hn in nodes)
                        {
                            if (tempString2.Length > 0) { tempString2 = tempString2 + ","; }
                            
                           tempString2 = tempString2 + hn.InnerText.ToString();
                          
                        }
         
                    }
                    

                    aa.tags = aa.stripNonValidXMLCharacters(tempString2);

                    // get reviews - _17mCT
                    int safetyCounter2 = 0; 
                    while (htmlDoc.DocumentNode.InnerHtml.ToString().IndexOf("_17mCT") != -1&& Int32.Parse(aa.numberReviews)+1>safetyCounter2)
                    {
                        safetyCounter2++;
                        try {
                            HtmlNode hn = htmlDoc.DocumentNode.SelectNodes("//div[contains(@class,'_17mCT')]").First();
                            
                               
                                userReview ur = new userReview();
                                int numOfNonStars = aa.CountStringOccurrences(hn.InnerHtml.ToString(), "_3IZbW ifont ifont-star - outline default");
                                ur.rating = (5-numOfNonStars).ToString();
                               
                                ur.title = hn.SelectNodes("//div[contains(@class,'_2GKDi')]").First().InnerText.ToString();
                                ur.title = aa.stripNonValidXMLCharacters(ur.title).Trim();
                                
                                ur.date = hn.SelectNodes("//div[contains(@class,'_2gdPy')]").First().InnerText.ToString();
                                ur.date = aa.stripNonValidXMLCharacters(ur.date).Trim();
                                
                                ur.review = hn.SelectNodes("//div[contains(@class,'Gbs5z')]").First().InnerText.ToString();
                                ur.review = aa.stripNonValidXMLCharacters(ur.review).Trim();
                                string tempData = "";
                                tempData = hn.SelectNodes("//div[contains(@class,'_3rgEi')]").First().InnerHtml.ToString();


                                tempData = tempData.Substring(tempData.IndexOf("bCYnm") +20);
                                ur.user = tempData.Substring(0, tempData.IndexOf('"'));
                                tempData = tempData.Substring(tempData.IndexOf("_20T9O") +7).Trim();
                                tempData = tempData.Substring(tempData.IndexOf(">")+1).Trim();
                                tempData = tempData.Substring(0,tempData.IndexOf("<")).Trim();
                                ur.onUnityVersion = aa.stripNonValidXMLCharacters(tempData).Trim();
                                

                                tempData = hn.SelectNodes("//div[contains(@class,'_3jIuv')]").First().InnerHtml.ToString();
                                tempData = tempData.Substring(tempData.IndexOf("_32c6X")+8);
                                ur.usefull = tempData.Substring(0,tempData.IndexOf("<"));

                                tempData = tempData.Substring(tempData.IndexOf("_32c6X") + 8);
                                ur.notUserfull = tempData.Substring(0, tempData.IndexOf("<"));

                                //MessageBox.Show(ur.usefull+","+ ur.notUserfull);
                               

                                if (hn.InnerHtml.ToString().IndexOf("_3nonQ") != -1)
                                {
                                    ur.replyFromPublisher = "yes";
                                }
                                else
                                {
                                    ur.replyFromPublisher = "no";
                                }

                                aa.userReviewsList.AddLast(ur);

                                htmlDoc.DocumentNode.SelectNodes("//div[contains(@class,'_17mCT')]").First().Remove();
                                
                               // MessageBox.Show(ur.getInString());

                            

                        }
                        catch
                        {
                            string output = "An exception has occur while proccessing the reviews at link " + aa.url;
                            //Console.WriteLine(output);
                            listOfErrors.AddLast(output);
                            button3.Visible = true;
                        }
                        }





                }
                catch
                {
                    if (secCounter < 3)
                    {// retry
                        listOfErrors.AddLast("Re-tried URL:"+ aa.url);
                        goto Processing;
                    }
                    else
                    {
                        string output = "An exception has occur while proccessing " + aa.url;
                        //Console.WriteLine(output);
                        listOfErrors.AddLast(output);
                        button3.Visible = true;
                    }
                    
                }

                Assets.AddLast(aa);


               

                    tempCount++;
                
                    backupCount++;
                               
                    if (backupCount == 100) { backupSave(); backupCount = 0;  } // save all data to a file, every x entries

             

                



            }
            backupSave();
            tempAssets.Clear();
            finishTime = DateTime.Now.ToString("yyyy-MM-dd h:mm:ss tt");
            label1.Text = "Assets added:" + tempCount.ToString() + " Assets under this category:" + numberOfAssetsFound
                + " Started:" + startTime + " Finished:" + finishTime;

            label2.Text = "Downloaded Assets: " + Assets.Count().ToString();

            button1.Enabled = true;
            button4.Enabled = true;






        }
     
        private void button1_Click(object sender, EventArgs e)
        {

            getData(false);
                
        
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void webBrowser2_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
           

        }
        
        


        private void button2_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 1 || comboBox1.SelectedIndex < 1)
            {// if file with complete XML or ALL files

                // generate file with complete XML 
                using (StreamWriter outputFile = new StreamWriter(Path.Combine(textBox1.Text, textBox2.Text)))
                {

                    outputFile.WriteLine("<assets>");
                    outputFile.WriteLine("<DataCollectionDate>Data were collected from :" + startTime + " to " + finishTime + "</DataCollectionDate>");
                    foreach (asset row in Assets)
                    {

                        outputFile.WriteLine(row.returnXMLRow());
                    }
                    outputFile.WriteLine("</assets>");
                    outputFile.Close();
                }

                label1.Text = textBox2.Text + " file Generated";

                webBrowser2.Navigate(textBox1.Text + "/" + textBox2.Text);



            }
           
            if (comboBox1.SelectedIndex == 3 || comboBox1.SelectedIndex < 1)
            {// if FSE or ALL files
                using (StreamWriter outputFile = new StreamWriter(Path.Combine(textBox1.Text, "FSE_" + textBox2.Text)))
                {
                    outputFile.WriteLine("<Features>");
                    outputFile.WriteLine("<DataCollectionDate>Data were collected from :" + startTime + " to " + finishTime + "</DataCollectionDate>");
                    foreach (asset row in Assets) { outputFile.WriteLine(row.returnXMLRowForFSE());  }
                    outputFile.WriteLine("</Features>");
                    outputFile.Close();
                }
                label1.Text = "FSE_" + textBox2.Text + " file Generated";
                webBrowser2.Navigate(textBox1.Text + "/" + "FSE_" + textBox2.Text);
            }
            if (comboBox1.SelectedIndex == 4||comboBox1.SelectedIndex < 1)
            {// if FSE LITE or ALL files
                using (StreamWriter outputFile = new StreamWriter(Path.Combine(textBox1.Text, "FSE_LITE_" + textBox2.Text)))
                {
                    outputFile.WriteLine("<Features>");
                    outputFile.WriteLine("<DataCollectionDate>Data were collected from :" + startTime + " to " + finishTime + "</DataCollectionDate>");
                    foreach (asset row in Assets) { outputFile.WriteLine(row.returnXMLRowForFSE_LITE()); }
                    outputFile.WriteLine("</Features>");
                    outputFile.Close();
                }
                label1.Text = "FSE_LITE_" + textBox2.Text + " file Generated";
                webBrowser2.Navigate(textBox1.Text + "/" + "FSE_LITE_" + textBox2.Text);
            }
            if (comboBox1.SelectedIndex == 5 || comboBox1.SelectedIndex < 1)
            {// if file with complete XML or ALL files

                // generate file with complete XML with reviews
                using (StreamWriter outputFile = new StreamWriter(Path.Combine(textBox1.Text, "CompleteWithReviews_"+textBox2.Text)))
                {

                    outputFile.WriteLine("<assets>");
                    outputFile.WriteLine("<DataCollectionDate>Data were collected from :" + startTime + " to " + finishTime + "</DataCollectionDate>");
                    foreach (asset row in Assets)
                    {

                        outputFile.WriteLine(row.returnXMLRowWithReviews());
                    }
                    outputFile.WriteLine("</assets>");
                    outputFile.Close();
                }

                label1.Text = "CompleteWithReviews_" + textBox2.Text + " file Generated";

                webBrowser2.Navigate(textBox1.Text + "/" + "CompleteWithReviews_" + textBox2.Text);



            }
            if (comboBox1.SelectedIndex == 6 || comboBox1.SelectedIndex < 1)
            {// if FSE or ALL files
                using (StreamWriter outputFile = new StreamWriter(Path.Combine(textBox1.Text, "FSEwithReviews_" + textBox2.Text)))
                {
                    outputFile.WriteLine("<Features>");
                    outputFile.WriteLine("<DataCollectionDate>Data were collected from :" + startTime + " to " + finishTime + "</DataCollectionDate>");
                    foreach (asset row in Assets) { outputFile.WriteLine(row.returnXMLRowForFSEwithReviews()); }
                    outputFile.WriteLine("</Features>");
                    outputFile.Close();
                }
                label1.Text = "FSEwithReviews_" + textBox2.Text + " file Generated";
                webBrowser2.Navigate(textBox1.Text + "/" + "FSEwithReviews_" + textBox2.Text);
            }
            if (comboBox1.SelectedIndex == 2 || comboBox1.SelectedIndex < 1)
            {// if LITE or ALL files
                using (StreamWriter outputFile = new StreamWriter(Path.Combine(textBox1.Text, "Lite_" + textBox2.Text)))
                {

                    outputFile.WriteLine("<assets>");
                    outputFile.WriteLine("<DataCollectionDate>Data were collected from :" + startTime + " to " + finishTime + "</DataCollectionDate>");
                    foreach (asset row in Assets)
                    {

                        outputFile.WriteLine(row.returnXMLRowLite());
                    }
                    outputFile.WriteLine("</assets>");
                    outputFile.Close();
                }

                label1.Text = "Lite_" + textBox2.Text + " file Generated";

                webBrowser2.Navigate(textBox1.Text + "/" + "Lite_" + textBox2.Text);


            }


        }
        public void backupSave()
        {
            try
            {
                using (StreamWriter outputFile = new StreamWriter(Path.Combine(textBox1.Text, "incomplete_" + textBox2.Text)))
                {

                    outputFile.WriteLine("<assets>");
                    outputFile.WriteLine("<DataCollectionDate>Data were collected from :" + startTime + " to " + finishTime + "</DataCollectionDate>");
                    foreach (asset row in Assets)
                    {
                        outputFile.WriteLine(row.returnXMLRow());
                    }
                    outputFile.WriteLine("</assets>");
                    outputFile.Close();
                }
            }
            catch 
            {
                string output = "An exception has occur while creating a backup " ;
                //Console.WriteLine(output);
                listOfErrors.AddLast(output);
                button3.Visible = true;
            }

        }
        private void button3_Click(object sender, EventArgs e)
        {
            using (StreamWriter outputFile = new StreamWriter(Path.Combine(textBox1.Text, "Errors_" + textBox2.Text.Substring(0, textBox2.Text.Length - 3) + "txt")))
            {
                foreach (string row in listOfErrors)
                {
                    outputFile.WriteLine(row);
                }
            }
            MessageBox.Show("The errors have been exported to file " + "Errors_" + textBox2.Text.Substring(0,textBox2.Text.Length-3)+"txt");
            webBrowser2.Navigate(textBox1.Text + "/" + "Errors_" + textBox2.Text.Substring(0, textBox2.Text.Length - 3) + "txt");
           // MessageBox.Show(textBox1.Text + "/" + "Errors_" + textBox2.Text.Substring(0, textBox2.Text.Length - 3) + "txt");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            getData(true);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {

            //  System.IO.StreamReader file = new System.IO.StreamReader(openFileDialog1.FileName);

            // repair file 
            //   string abc = file.ReadToEnd();
            //   file.Close();
            System.IO.StreamReader file = new System.IO.StreamReader(Path.Combine(textBox1.Text,"UnityAssetsStoreDataOLD.xml"));
            MessageBox.Show("file done");
            string line;

            LinkedList<string> ll = new LinkedList<string>();
            int counter = 0;
            while ((line = file.ReadLine()) != null)
            {
                string abc = removeUnwantedChar(line);
                ll.AddLast(abc);
                counter++;
                System.Console.WriteLine(counter);
                
            }

            file.Close();



          
                MessageBox.Show("file uploaded and update in RAM");

            using (StreamWriter outputFile = new StreamWriter(Path.Combine(textBox1.Text, "new_" + textBox2.Text)))
            {

                outputFile.WriteLine("<assets>");
                outputFile.WriteLine("<DataCollectionDate>Data were collected from :" + startTime + " to " + finishTime + "</DataCollectionDate>");
                foreach (string abc in ll) { 
                outputFile.WriteLine(abc);
            }
                    outputFile.WriteLine("</assets>");
                    outputFile.Close();
                }
                MessageBox.Show("done");
            
            }
    }
}
